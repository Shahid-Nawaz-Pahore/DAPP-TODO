import NavBar from "../components/NavBar";


export default function Home() {
  return (
    // <main       
    // style={{
    //   display: 'flex',
    //   justifyContent: 'flex-end',
    //   padding: 12,
    // }}
    // >
     
    // </main>
   < NavBar/>
  );
}
