/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
exports.id = "vendor-chunks/isomorphic-unfetch";
exports.ids = ["vendor-chunks/isomorphic-unfetch"];
exports.modules = {

/***/ "(ssr)/./node_modules/isomorphic-unfetch/index.js":
/*!**************************************************!*\
  !*** ./node_modules/isomorphic-unfetch/index.js ***!
  \**************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

eval("function r(m){return m && m.default || m;}\nmodule.exports = global.fetch = global.fetch || (\n\ttypeof process=='undefined' ? r(__webpack_require__(/*! unfetch */ \"(ssr)/./node_modules/unfetch/dist/unfetch.module.js\")) : (function(url, opts) {\n\t\treturn r(__webpack_require__(/*! node-fetch */ \"(ssr)/./node_modules/node-fetch/lib/index.mjs\"))(String(url).replace(/^\\/\\//g,'https://'), opts);\n\t})\n);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHNzcikvLi9ub2RlX21vZHVsZXMvaXNvbW9ycGhpYy11bmZldGNoL2luZGV4LmpzIiwibWFwcGluZ3MiOiJBQUFBLGNBQWM7QUFDZDtBQUNBLGlDQUFpQyxtQkFBTyxDQUFDLG9FQUFTO0FBQ2xELFdBQVcsbUJBQU8sQ0FBQyxpRUFBWTtBQUMvQixFQUFFO0FBQ0YiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jb25uZXQtd2FsbGV0Ly4vbm9kZV9tb2R1bGVzL2lzb21vcnBoaWMtdW5mZXRjaC9pbmRleC5qcz9lYzFlIl0sInNvdXJjZXNDb250ZW50IjpbImZ1bmN0aW9uIHIobSl7cmV0dXJuIG0gJiYgbS5kZWZhdWx0IHx8IG07fVxubW9kdWxlLmV4cG9ydHMgPSBnbG9iYWwuZmV0Y2ggPSBnbG9iYWwuZmV0Y2ggfHwgKFxuXHR0eXBlb2YgcHJvY2Vzcz09J3VuZGVmaW5lZCcgPyByKHJlcXVpcmUoJ3VuZmV0Y2gnKSkgOiAoZnVuY3Rpb24odXJsLCBvcHRzKSB7XG5cdFx0cmV0dXJuIHIocmVxdWlyZSgnbm9kZS1mZXRjaCcpKShTdHJpbmcodXJsKS5yZXBsYWNlKC9eXFwvXFwvL2csJ2h0dHBzOi8vJyksIG9wdHMpO1xuXHR9KVxuKTtcbiJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(ssr)/./node_modules/isomorphic-unfetch/index.js\n");

/***/ })

};
;